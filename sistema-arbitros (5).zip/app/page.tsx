"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  CalendarDays,
  Users,
  Trophy,
  UserCheck,
  Calendar,
  FileText,
  Shield,
  Clock,
  Menu,
  X,
  Plus,
  BarChart3,
} from "lucide-react"
import { useDataStore } from "@/lib/data-store"

export default function Home() {
  const { arbitros, campeonatos, designaciones, asistencias, loadData, getDaysUntilExpiration } = useDataStore()
  const [isLoading, setIsLoading] = useState(true)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    loadData()
    setIsLoading(false)
  }, [loadData])

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-slate-200 border-t-blue-600 mx-auto" />
          <p className="text-lg text-slate-600">Cargando sistema...</p>
        </div>
      </div>
    )
  }

  const arbitrosDisponibles = arbitros.filter((a) => a.disponible).length
  const campeonatosActivos = campeonatos.filter((c) => c.estado === "activo").length
  const daysUntilExpiration = getDaysUntilExpiration()

  // Asistencia de hoy
  const hoy = new Date()
  const asistenciasHoy = asistencias.filter((a) => {
    const fechaAsistencia = new Date(a.fecha)
    return fechaAsistencia.toDateString() === hoy.toDateString()
  })
  const arbitrosConAsistenciaHoy = new Set(asistenciasHoy.map((a) => a.arbitroId)).size

  const menuItems = [
    {
      title: "Gestión de Árbitros",
      items: [
        { name: "Ver Árbitros", href: "/arbitros", icon: Users },
        { name: "Nuevo Árbitro", href: "/arbitros/nuevo", icon: Plus },
      ],
    },
    {
      title: "Asistencia",
      items: [
        { name: "Pasar Asistencia", href: "/asistencia", icon: UserCheck },
        { name: "Estadísticas", href: "/asistencia/estadisticas", icon: BarChart3 },
      ],
    },
    {
      title: "Designaciones",
      items: [
        { name: "Nueva Designación", href: "/designaciones/nueva", icon: Plus },
        { name: "Ver Designaciones", href: "/designaciones", icon: Calendar },
      ],
    },
    {
      title: "Sistema",
      items: [
        { name: "Campeonatos", href: "/campeonatos", icon: Trophy },
        { name: "Reportes PDF", href: "/reportes", icon: FileText },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header con menú */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center">
                <Shield className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900">Sistema de Árbitros</h1>
                <p className="text-xs text-slate-600">Gestión Profesional</p>
              </div>
            </div>

            {/* Menú Desktop */}
            <nav className="hidden md:flex items-center space-x-1">
              {menuItems.map((section) => (
                <div key={section.title} className="relative group">
                  <Button variant="ghost" className="text-slate-600 hover:text-slate-900 hover:bg-slate-100">
                    {section.title}
                  </Button>
                  <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-lg shadow-lg border border-slate-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                    <div className="py-2">
                      {section.items.map((item) => (
                        <Link
                          key={item.name}
                          href={item.href}
                          className="flex items-center space-x-3 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 hover:text-slate-900"
                        >
                          <item.icon className="h-4 w-4" />
                          <span>{item.name}</span>
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </nav>

            {/* Botón menú móvil */}
            <Button variant="ghost" size="sm" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Menú móvil */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-200">
            <div className="px-4 py-2 space-y-1">
              {menuItems.map((section) => (
                <div key={section.title} className="space-y-1">
                  <div className="px-3 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wide">
                    {section.title}
                  </div>
                  {section.items.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className="flex items-center space-x-3 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-md"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </Link>
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Advertencia de expiración */}
        {daysUntilExpiration <= 7 && daysUntilExpiration > 0 && (
          <Card className="mb-6 border-amber-200 bg-amber-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Clock className="h-5 w-5 text-amber-600" />
                  <div>
                    <h3 className="font-semibold text-amber-900">Datos próximos a expirar</h3>
                    <p className="text-sm text-amber-700">
                      Los datos expirarán en {daysUntilExpiration} días. Gestiona la persistencia en Reportes.
                    </p>
                  </div>
                </div>
                <Button asChild variant="outline" className="border-amber-300 text-amber-700 hover:bg-amber-100">
                  <Link href="/reportes">Gestionar</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Métricas principales */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="border-0 shadow-sm bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Árbitros Disponibles</p>
                  <p className="text-2xl font-bold text-slate-900">{arbitrosDisponibles}</p>
                  <p className="text-xs text-slate-500">de {arbitros.length} total</p>
                </div>
                <div className="h-12 w-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Campeonatos Activos</p>
                  <p className="text-2xl font-bold text-slate-900">{campeonatosActivos}</p>
                  <p className="text-xs text-slate-500">en curso</p>
                </div>
                <div className="h-12 w-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <Trophy className="h-6 w-6 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Presentes Hoy</p>
                  <p className="text-2xl font-bold text-slate-900">{arbitrosConAsistenciaHoy}</p>
                  <p className="text-xs text-slate-500">árbitros</p>
                </div>
                <div className="h-12 w-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <UserCheck className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Designaciones</p>
                  <p className="text-2xl font-bold text-slate-900">{designaciones.length}</p>
                  <p className="text-xs text-slate-500">realizadas</p>
                </div>
                <div className="h-12 w-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <CalendarDays className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Acciones principales */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          <Card className="border-0 shadow-sm bg-white hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="h-12 w-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <UserCheck className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Control de Asistencia</h3>
              <p className="text-sm text-slate-600 mb-4">Registra la asistencia diaria de los árbitros</p>
              <Button asChild className="w-full">
                <Link href="/asistencia">Pasar Asistencia</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-white hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="h-12 w-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Gestión de Árbitros</h3>
              <p className="text-sm text-slate-600 mb-4">Administra la información de árbitros</p>
              <Button asChild variant="outline" className="w-full">
                <Link href="/arbitros">Ver Árbitros</Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm bg-white hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="h-12 w-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Nueva Designación</h3>
              <p className="text-sm text-slate-600 mb-4">Asignar árbitros a partidos</p>
              <Button asChild variant="outline" className="w-full">
                <Link href="/designaciones/nueva">Crear Designación</Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Información del día */}
        <Card className="border-0 shadow-sm bg-white">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5" />
              <span>Actividad de Hoy</span>
            </CardTitle>
            <CardDescription>
              {hoy.toLocaleDateString("es-ES", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-3">
              <div className="text-center p-4 bg-slate-50 rounded-lg">
                <h4 className="font-semibold text-slate-900 mb-1">Tipo de Actividad</h4>
                <p className="text-lg font-medium text-blue-600">
                  {[1, 2, 4].includes(hoy.getDay())
                    ? "Preparación Física"
                    : hoy.getDay() === 5
                      ? "Entrenamiento"
                      : "Sin Actividad"}
                </p>
              </div>

              <div className="text-center p-4 bg-slate-50 rounded-lg">
                <h4 className="font-semibold text-slate-900 mb-1">Árbitros Presentes</h4>
                <p className="text-lg font-medium text-green-600">
                  {arbitrosConAsistenciaHoy} / {arbitros.length}
                </p>
              </div>

              <div className="text-center p-4 bg-slate-50 rounded-lg">
                <h4 className="font-semibold text-slate-900 mb-1">Horario</h4>
                <p className="text-lg font-medium text-purple-600">
                  {[1, 2, 4, 5].includes(hoy.getDay()) ? "18:00 - 20:00" : "No programado"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
